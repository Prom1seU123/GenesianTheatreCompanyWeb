package com.au.GenesianTheatreCompany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenesianTheatreCompanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
